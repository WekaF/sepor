<?php $__env->startSection('js'); ?>

<script type="text/javascript">

$(document).ready(function() {
    $(".users").select2();
});

</script>

<script type="text/javascript">
        function readURL() {
            var input = this;
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $(input).prev().attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $(function () {
            $(".uploads").change(readURL)
            $("#f").submit(function(){
                // do ajax submit or just classic form submit
              //  alert("fake subminting")
                return false
            })
        })
        </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','Detail Denah'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Detail <b><?php echo e($data->nama_denah); ?></b> </h4>
                      <form class="forms-sample">

                        <div class="form-group">
                            <div class="col-md-6">
                                <img style="width:400px; height:300px" <?php if($data->gambar): ?> src="<?php echo e(asset('images/denah/'.$data->gambar)); ?>" <?php endif; ?> />
                            </div>                            
                        </div>

                        <div class="form-group<?php echo e($errors->has('judul') ? ' has-error' : ''); ?>">
                            <label for="judul" class="col-md-4 control-label"><b>Deskripsi</b></label>
                            <div class="col-md-6">
                                <p><?php echo e($data->deskripsi); ?></p>
                            </div>
                        </div>

                                                
                        <a href="<?php echo e(route('stasiuninfo.index')); ?>" class="btn btn-light pull-right">Back</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/stasiuninfo/show.blade.php ENDPATH**/ ?>