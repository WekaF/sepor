<?php $__env->startSection('title','Edit Taxi'); ?>


<?php $__env->startSection('content'); ?>

<div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Tambah Data</h4>
                    
                    <form class="forms-sample" method="POST" action="<?php echo e(route('taxi.update', $data->id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <div class="form-group">
                        <label for="taxi_name">Nama Taxi</label>
                        <input name='taxi_name' type="text" class="form-control" placeholder="nama taxi" value="<?php echo e($data->taxi_name); ?>">
                       
                      </div>
                      <div class="form-group">
                        <label for="taxi_price">Harga</label>
                        <input name='taxi_price' type="text" class="form-control" placeholder="harga" value="<?php echo e($data->taxi_price); ?>">
                      </div>
                                    

                      <div class="form-group">
                        <label for="exampleTextarea1">Deskripsi</label>
                        <textarea name="taxi_desc" class="form-control" id="exampleTextarea1" rows="4"><?php echo e($data->taxi_desc); ?></textarea>
                      </div>

                      <button type="submit" class="btn btn-success mr-2">Update</button>
                      <a href="<?php echo e(route('taxi.index')); ?>">
                      <button class="btn btn-light">Cancel</button>
                      </a>
                    </form>
                  </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/taxi/edit.blade.php ENDPATH**/ ?>