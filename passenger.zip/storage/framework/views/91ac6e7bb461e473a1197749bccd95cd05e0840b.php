<?php $__env->startSection('title','Edit Kontak'); ?>


<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('kontak.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('put')); ?>

<div class="row">
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Edit Kategori <b><?php echo e($data->jenis); ?></b> </h4>
                      <form class="forms-sample">
                        
                      <div class="form-group">
                            <label for="deskripsi" class="col-md-4 control-label">jenis</label>
                            <div class="col-md-6">
                                 <select name="jenis" class="form-control" value="<?php echo e($data->jenis); ?>">
                                    <option value="">-- Pilih Kategori --</option>
                                    <option value="darurat">Darurat</option>
                                    <option value="pelanggan">Pelanggan</option>
                                  </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="judul" class="col-md-4 control-label">Nama Kontak</label>
                            <div class="col-md-6">
                                <input id="isbn" type="text" class="form-control" name="nama" value="<?php echo e($data->nama); ?>"required>
                            </div>
                        
                            <div class="form-group">
                            <label for="judul" class="col-md-4 control-label">Nomer Kontak</label>
                            <div class="col-md-6">
                                <input id="isbn" type="text" class="form-control" name="nomor" value="<?php echo e($data->nomor); ?>"required>
                            </div>
                            </div>
                        <button type="submit" class="btn btn-primary" id="submit">
                                    Update
                        </button>
                        <a href="<?php echo e(route('kontak.index')); ?>" class="btn btn-light pull-right">Back</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

</div>
</div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/kontak/edit.blade.php ENDPATH**/ ?>