<?php $__env->startSection('pageTitle'); ?>Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card-deck">
<?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4">
            <div class="card">
              <h3 class="card-title"><strong><?php echo e($item->judul); ?></strong> <br>
              <span><small class="text-twitter"><b>Passenger</b> </small></span>
              <span><small class="text-muted"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></small></span>
            </h3>
              <div class="card-body">
                <figure class="teaser teaser-zoe">
                <a href="<?php echo e(route('web.show',$item->id)); ?>">
                <img src="<?php echo e(url('images/berita/'. $item->gambar)); ?>" alt="gambar" style="widht:300px; height:300px" >
                </a>
                  <figcaption>
                    <p class="icon-links">
                      <a href="#"><span class="fa fa-heart"></span></a>
                      <a href="#"><span class="fa fa-eye"></span></a>
                      <a href="#"><span class="fa fa-paperclip"></span></a>
                    </p>
                    <p class="description"><?php echo e($item->judul); ?></p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-md-12 pt-2 pl-0 pr-0">
<?php echo $berita->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('csspage'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scriptpage'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('indexmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/home.blade.php ENDPATH**/ ?>