<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table').DataTable({
      "iDisplayLength": 10
    });

} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Dashboard'); ?>



<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-6 col-lg-3">
            <div class="card card-body ">
              <h6 class="text-uppercase text-gray">Angkutan</h6>
              <div class="flexbox mt-2">
                <span class="fa fa-car text-gray fs-30"></span>
                <span class="fs-30"><?php echo e($trayek->count()); ?></span>
              </div>
            </div>
          </div>



          <div class="col-6 col-lg-3">
            <div class="card card-body bg-gray">
              <h6 class="text-uppercase text-white">Destinasi</h6>
              <div class="flexbox mt-2">
                <span class="fa fa-plus text-white fs-30"></span>
                <span class="fs-30"><?php echo e($subkategori->count()); ?></span>
              </div>
            </div>
          </div>




          <div class="col-6 col-lg-3">
            <div class="card card-body bg-danger">
              <h6 class="text-uppercase text-white">Taxi</h6>
              <div class="flexbox mt-2">
                <span class="fa fa-car fs-30"></span>
                <span class="fs-30"><?php echo e($taxi->count()); ?></span>
              </div>
            </div>
          </div>



          <div class="col-6 col-lg-3">
            <div class="card card-body bg-info">
              <h6 class="text-uppercase text-white">Kereta</h6>
              <div class="flexbox mt-2">
                <span class="fa fa-train fs-30"></span>
                <span class="fs-30">
                  <?php echo e($detail->count()); ?>

                </span>
              </div>
            </div>
		  </div>
		  
<div class="col-lg-12">
  <div class="divider text-uppercase fw-500">Informasi</div>
</div>


         
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h3 class="text-center font-weight-bold">INFORMASI KERETA API</h3>
                   
                    <table id="" class="table table-striped table-bordered" width="100%">
                        <thead class="table-dark">
                          <tr>
                                  <th width="5px">No</th>
                                  <th width="50px">Kategori</th>
                                  <th width="100px">Nama Kereta</th>
                                  <th width="100px">Relasi</th>
                                  <th width="10px">Jam</th>
                                  <th width="10px">Keterangan</th>
                                 
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                <td>
                                <a href="<?php echo e(route('keretainfo.show', $data->id)); ?>"> 
                                <?php echo e($data->no_ka); ?>

                                </a>
                                </td>
                                <td><?php echo e($data->jenis->jenis_kereta); ?></td>
                                <td><?php echo e($data->nama_kereta); ?></td>
                                <td><?php echo e($data->relasi); ?></td> 
                                <td><?php echo e($data->jam); ?></td>
                                <td>
                                <?php if($data->keterangan == "Normal"): ?>
                                <span class="badge badge-success"><?php echo e($data->keterangan); ?></span>
                                <?php else: ?>
                                <span class="badge badge-danger"><?php echo e($data->keterangan); ?></span>
                                <?php endif; ?>

                                </td>
                              
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                  </div>
                </div>
              </div>
          
             
              
          <div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="text-center font-weight-bold">Kontak</h4>
                    <table id="" class="table table-striped">
                      <thead>
                        <tr>
                        <th>Jenis</th>
                        <th>Nama Kontak</th>
                        <th>Nomor</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                  <td><?php echo e($data->jenis); ?></td>
                                  <td><?php echo e($data->nama); ?></td>
                                  <td><?php echo e($data->nomor); ?></td>
                                  
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              
              <div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="text-center font-weight-bold">Data Destinasi</h4>
                    <table id="table" class="table table-striped">
                      <thead>
                        <tr>
                          <th> Nama Destinasi </th>
                          <th> Kategori </th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $subkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                  <td><?php echo e($datang->nama_subkategori); ?></td>
                                  <td><?php echo e($datang->kategori->nama_kategori); ?></td>
                                  
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

     
              

              <div class="col-md-12">
            <div class="card">
              <h5 class="card-title text-center">List<strong> Berita</strong></h5>

              <div class="media-list media-list-hover media-list-divided">

              <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="media media-single" href="<?php echo e(route('web.show',$item->id)); ?>">
                  <img class="w-60px" src="<?php echo e(url('images/berita/'. $item->gambar)); ?>" alt="...">
                  <div class="media-body">
                    <h5><?php echo e($item->judul); ?></h5>
                    <small class="text-fader"><i class="fa fa-info pr-1"></i> <?php echo e($item->isi); ?></small>
                  </div>
                  <span class="media-right text-fade"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span>
                </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

            </div>
          </div>


        <div class="col-md-8">
            <div class="card">
              <h5 class="card-title text-center">List<strong> Feedback</strong></h5>

              <div class="media-list media-list-hover media-list-divided">

              <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <header class="card-header bg-lightest">
               
                  <div class="card-title flexbox">
                    <img class="avatar" src="<?php echo e(asset('assets/img/avatar/1.jpg')); ?>" alt="...">
                    <div>
                      <h6 class="mb-0"><?php echo e($data->nama); ?> <small class="sidetitle fs-11"><?php echo e($data->email); ?></small></h6>
                      <small><?php echo e(Carbon\Carbon::parse($data->created_at)->diffForHumans()); ?></small>
                    </div>
                  </div>
                </header>
                <div class="card-body">
                  <p><?php echo e($data->saran); ?></p>
                </div>
                <div class="divider text-uppercase fw-500"></div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              </div>

              <?php echo e($feedback->links()); ?>


            </div>
          </div>






       
</div>


	 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/dashboard.blade.php ENDPATH**/ ?>