<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table').DataTable({
      "iDisplayLength": 50
    });

} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Jenis Kereta Api'); ?>


<?php $__env->startSection('content'); ?> 

<div class="row">
<div class="col-lg-6 grid-margin stretch-card">      
          <div class="card">
          <h4 class="card-title"><strong>Tambah</strong> Jenis Kereta</h4>
          <div class="col-lg-2">
            <a href="<?php echo e(route('jeniska.create')); ?>" class="btn btn-primary btn-rounded btn-fw"><i class="fa fa-plus"></i> Tambah Data</a>
          </div>

          <div class="card-body">

            <table class="table table-striped table-bordered" cellspacing="0" data-provide="datatables">
              <thead>
                <tr>
                <th>ID</th>
                <th>Nama kategori</th>

                </tr>
              </thead>
              <tbody>
             
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($data->id); ?></td>
                                  <td><?php echo e($data->jenis_kereta); ?></td>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
           </div>

           
           </div>
           </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/jeniska/index.blade.php ENDPATH**/ ?>