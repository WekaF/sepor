<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table').DataTable({
      "iDisplayLength": 10
    });

} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Angkutan'); ?>


<?php $__env->startSection('content'); ?>

              <div class="card">
          <h4 class="card-title"><strong>Tambah</strong> Angkutan</h4>
          <div class="col-lg-2">
            <a href="<?php echo e(route('trayek.create')); ?>" class="btn btn-primary btn-rounded btn-fw"><i class="fa fa-plus"></i> Tambah Data</a>
          </div>

          <div class="card-body">

            <table class="table table-striped table-bordered" cellspacing="0" data-provide="datatables">
              <thead>
                <tr>
                <th>Nama Angkutan</th>
                <th>Harga</th>
                <th>Deskripsi</th>
                <th>Gambar</th>
                <th>Action</th>
                </tr>
              </thead>
              <tbody>
             
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                  <td><?php echo e($datang->trayek_name); ?></td>
                                  <td><?php echo e($datang->trayek_price); ?></td>
                                  <td><?php echo e($datang->trayek_desc); ?></td>
                                  <td class="py-1">
                                      <?php if($datang->gambar): ?>
                                        <img src="<?php echo e(url('images/trayek/'. $datang->gambar)); ?>" alt="image" style="width: 100px; height:100px " />
                                      <?php else: ?>
                                        <img src="<?php echo e(url('images/trayek/default.jpg')); ?>" alt="image" style="width: 100px; height:100px" />
                                      <?php endif; ?>
                                  
                                      </td>
                                 
                                  <td>
                            <div class="btn-group dropdown">
                            <button type="button" class="btn btn-success dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                            </button>
                            <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 30px, 0px);">
                              <a class="dropdown-item" href="<?php echo e(route('trayek.edit', $datang->id)); ?>"> Edit </a>
                              <form action="<?php echo e(route('trayek.destroy',$datang->id)); ?>" class="pull-left"  method="POST">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <button class="dropdown-item" onclick="return confirm('Anda yakin ingin menghapus data ini?')"> Delete
                              </button>
                            </form>
                            </div>
                          </div>
                            </td>

                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>

           
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/trayek/index.blade.php ENDPATH**/ ?>