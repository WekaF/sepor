<?php $__env->startSection('title','Edit Kategori Destinasi'); ?>


<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('kategori.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('put')); ?>

<div class="row">
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Edit Kategori <b><?php echo e($data->nama_kategori); ?></b> </h4>
                      <form class="forms-sample">
                        <div class="form-group<?php echo e($errors->has('judul') ? ' has-error' : ''); ?>">
                            <label for="judul" class="col-md-4 control-label">Nama Kategori</label>
                            <div class="col-md-6">
                                <input id="judul" type="text" class="form-control" name="nama_kategori" value="<?php echo e($data->nama_kategori); ?>" required>
                                <?php if($errors->has('judul')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('judul')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" id="submit">
                                    Update
                        </button>
                        <a href="<?php echo e(route('kategori.index')); ?>" class="btn btn-light pull-right">Back</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/kategori/edit.blade.php ENDPATH**/ ?>