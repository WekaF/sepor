

// =====================
// Map plugins
// =====================
//
+function($){

  provider.initMaps = function() {

  };


  provider.initMap = function() {

  };



  provider.initMapael = function() {

  };


}(jQuery);
