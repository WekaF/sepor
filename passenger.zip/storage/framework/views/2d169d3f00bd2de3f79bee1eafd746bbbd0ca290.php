<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table').DataTable({
      "iDisplayLength": 10
    });

} );
</script>

<script type="text/javascript">
$('.delete-confirm').on('click', function (event) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Are you sure?',
        text: 'This record and it`s details will be permanantly deleted!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Kategori Destinasi'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-8 grid-margin stretch-card">      
          <div class="card">
          <h4 class="card-title"><strong>Tambah</strong> Kategori Destinasi</h4>
          <div class="col-lg-2">
            <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary btn-rounded btn-fw"><i class="fa fa-plus"></i> Tambah Data</a>
          </div>

          <div class="card-body">

            <table class="table table-striped table" cellspacing="0" data-provide="datatables">
              <thead>
                <tr>
                <th>Nama kategori</th>
                <th>Action</th>
                </tr>
              </thead>
              <tbody>
             
              <?php $__currentLoopData = $Kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            		<tr>
                    <td><?php echo e($datang->nama_kategori); ?></td>
                           
                    <td>
                            <div class="btn-group dropdown">
                            <button type="button" class="btn btn-success dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                            </button>
                            <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 30px, 0px);">
                              <a class="dropdown-item" href="<?php echo e(route('kategori.edit', $datang->id)); ?>"> Edit </a>
                              <form action="<?php echo e(route('kategori.destroy',$datang->id)); ?>" class="pull-left delete-confirm"  method="POST">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <button class="dropdown-item delete-confirm" onclick="return delete-confirm "> Delete
                              </button>
                            </form>
                            </div>
                          </div>
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views//kategori/index.blade.php ENDPATH**/ ?>