<?php $__env->startSection('pageTitle'); ?><?php echo $berita->judul; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-3"><?php echo $berita->judul; ?></h1>
    <p class="card-text" datetime="<?php echo e($berita->created_at); ?>" title="<?php echo e($berita->created_at); ?>"><small class="text-muted"><?php echo e(Carbon\Carbon::parse($berita->created_at)->diffForHumans()); ?></small></p>


<img src="<?php echo e(url('images/berita/'. $berita->gambar)); ?>" alt="" class="card-img-top pb-4 center-block" style="width: 500px; height:400px">

    <div class="lead"><?php echo $berita->isi; ?></div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('csspage'); ?>

<link rel="stylesheet" href="<?php echo asset('plugins/fontawesome/css/all.min.css'); ?>">
<link rel="stylesheet" href="<?php echo asset('plugins/baguetteBox/css/baguetteBox.css'); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scriptpage'); ?>
<script src="<?php echo asset('plugins/baguetteBox/js/baguetteBox.js'); ?>"></script>
<script>
    baguetteBox.run('.baguetteBox');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('indexmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepor\resources\views/showberita.blade.php ENDPATH**/ ?>